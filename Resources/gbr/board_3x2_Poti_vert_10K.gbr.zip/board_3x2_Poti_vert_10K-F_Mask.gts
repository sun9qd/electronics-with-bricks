%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:37+02:00*%
%TF.ProjectId,board_3x2_Poti_vert_10K,626f6172-645f-4337-9832-5f506f74695f,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.620000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X104770000Y-92495000D03*
X109770000Y-89995000D03*
X104770000Y-87495000D03*
%TD*%
M02*
