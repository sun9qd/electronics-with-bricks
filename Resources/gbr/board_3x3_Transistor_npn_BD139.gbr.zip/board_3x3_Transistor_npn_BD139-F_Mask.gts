%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:40+02:00*%
%TF.ProjectId,board_3x3_Transistor_npn_BD139,626f6172-645f-4337-9833-5f5472616e73,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:40*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.800000X1.710000*%
%ADD11O,1.800000X1.710000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X92260000Y-97120000D03*
D11*
X92260000Y-94840000D03*
X92260000Y-92560000D03*
%TD*%
M02*
