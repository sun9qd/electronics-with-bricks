%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:36+02:00*%
%TF.ProjectId,board_3x2_Poti_horz_10K,626f6172-645f-4337-9832-5f506f74695f,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:36*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.620000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X104350000Y-93500000D03*
X101850000Y-91000000D03*
X104350000Y-88500000D03*
%TD*%
M02*
