%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:30+02:00*%
%TF.ProjectId,board_3x1_LED,626f6172-645f-4337-9831-5f4c45442e6b,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:30*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.800000X1.800000*%
%ADD11C,1.800000*%
G04 APERTURE END LIST*
D10*
%TO.C,LED*%
X128359895Y-93013386D03*
D11*
X128359895Y-90473386D03*
%TD*%
M02*
