%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:48+02:00*%
%TF.ProjectId,board_4x3_Relay_5V_HJR_4102E,626f6172-645f-4347-9833-5f52656c6179,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:48*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.400000X1.400000*%
%ADD11C,1.400000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X100540000Y-104000000D03*
%TD*%
D11*
%TO.C,*%
X92920000Y-104000000D03*
%TD*%
%TO.C,*%
X100540000Y-101460000D03*
%TD*%
%TO.C,*%
X92920000Y-101460000D03*
%TD*%
%TO.C,*%
X92920000Y-91300000D03*
%TD*%
M02*
