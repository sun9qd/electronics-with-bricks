%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:39+02:00*%
%TF.ProjectId,board_3x2_Transistor_pnp_BC557C,626f6172-645f-4337-9832-5f5472616e73,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:39*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.500000X1.500000*%
%ADD11C,1.500000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X101720000Y-93550000D03*
D11*
X101720000Y-91010000D03*
X101720000Y-88470000D03*
%TD*%
M02*
