%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:40+02:00*%
%TF.ProjectId,board_3x3_JackSocket_EBS_35,626f6172-645f-4337-9833-5f4a61636b53,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:40*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X110182101Y-85741050D03*
X118182101Y-80541050D03*
X114082101Y-90341050D03*
X116982101Y-83241050D03*
X121382101Y-89841050D03*
%TD*%
M02*
