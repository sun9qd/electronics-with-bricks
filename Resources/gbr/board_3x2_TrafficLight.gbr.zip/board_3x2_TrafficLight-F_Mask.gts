%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:38+02:00*%
%TF.ProjectId,board_3x2_TrafficLight,626f6172-645f-4337-9832-5f5472616666,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,Traffic Light*%
X111540000Y-92460000D03*
D11*
X109000000Y-92460000D03*
X111540000Y-95000000D03*
X109000000Y-95000000D03*
X111540000Y-97540000D03*
X109000000Y-97540000D03*
%TD*%
M02*
