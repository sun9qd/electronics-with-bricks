%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:45+02:00*%
%TF.ProjectId,board_4x3_DAC_MCP4921,626f6172-645f-4347-9833-5f4441435f4d,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:45*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.400000*%
%ADD11C,1.600000*%
%ADD12RoundRect,0.250000X-0.550000X-0.550000X0.550000X-0.550000X0.550000X0.550000X-0.550000X0.550000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X105515980Y-92453845D03*
X105515980Y-87373845D03*
%TD*%
D11*
%TO.C,REF\u002A\u002A*%
X118089849Y-82000000D03*
X118089849Y-87000000D03*
%TD*%
D12*
%TO.C,REF\u002A\u002A*%
X107925000Y-84190000D03*
D11*
X107925000Y-86730000D03*
X107925000Y-89270000D03*
X107925000Y-91810000D03*
X115545000Y-91810000D03*
X115545000Y-89270000D03*
X115545000Y-86730000D03*
X115545000Y-84190000D03*
%TD*%
M02*
