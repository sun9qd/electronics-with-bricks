%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:34+02:00*%
%TF.ProjectId,board_3x1_Resistor_1K,626f6172-645f-4337-9831-5f5265736973,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:34*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.600000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X106276252Y-102039264D03*
X106276252Y-91879264D03*
%TD*%
M02*
