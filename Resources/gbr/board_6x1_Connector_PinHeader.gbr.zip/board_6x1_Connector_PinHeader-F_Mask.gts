%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:53+02:00*%
%TF.ProjectId,board_6x1_Connector_PinHeader,626f6172-645f-4367-9831-5f436f6e6e65,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:53*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X117730000Y-78650000D03*
X117730000Y-81190000D03*
X117730000Y-83730000D03*
X117730000Y-86270000D03*
X117730000Y-88810000D03*
X117730000Y-91350000D03*
%TD*%
M02*
