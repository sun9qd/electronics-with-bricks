%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:42+02:00*%
%TF.ProjectId,board_4x2_UniversalConnector,626f6172-645f-4347-9832-5f556e697665,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X97270000Y-97190000D03*
D11*
X97270000Y-99730000D03*
X97270000Y-102270000D03*
X97270000Y-104810000D03*
%TD*%
M02*
