%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:37+02:00*%
%TF.ProjectId,board_3x2_TempSensor_LM235Z,626f6172-645f-4337-9832-5f54656d7053,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.500000X1.500000*%
%ADD11C,1.500000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X104910000Y-87460000D03*
D11*
X104910000Y-90000000D03*
X104910000Y-92540000D03*
%TD*%
M02*
