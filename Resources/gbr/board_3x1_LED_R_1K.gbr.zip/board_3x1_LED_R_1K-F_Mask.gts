%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:30+02:00*%
%TF.ProjectId,board_3x1_LED_R_1K,626f6172-645f-4337-9831-5f4c45445f52,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:30*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.400000*%
%ADD11R,1.800000X1.800000*%
%ADD12C,1.800000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X99270000Y-89000000D03*
X99270000Y-83920000D03*
%TD*%
D11*
%TO.C,REF\u002A\u002A*%
X99270000Y-94080000D03*
D12*
X99270000Y-91540000D03*
%TD*%
M02*
