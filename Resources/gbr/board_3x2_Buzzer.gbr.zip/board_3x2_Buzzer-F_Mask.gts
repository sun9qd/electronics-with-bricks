%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:35+02:00*%
%TF.ProjectId,board_3x2_Buzzer,626f6172-645f-4337-9832-5f42757a7a65,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:35*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,2.000000X2.000000*%
%ADD11C,2.000000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X114270000Y-88750000D03*
D11*
X114270000Y-95250000D03*
%TD*%
M02*
