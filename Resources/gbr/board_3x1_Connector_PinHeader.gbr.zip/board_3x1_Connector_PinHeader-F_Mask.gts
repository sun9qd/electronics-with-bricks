%TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*%
%TF.CreationDate,2026-10-08T09:55:28+02:00*%
%TF.ProjectId,board_3x1_Connector_PinHeader,626f6172-645f-4337-9831-5f436f6e6e65,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-10-08 09:55:28*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X113270000Y-91460000D03*
D11*
X113270000Y-94000000D03*
X113270000Y-96540000D03*
%TD*%
M02*
